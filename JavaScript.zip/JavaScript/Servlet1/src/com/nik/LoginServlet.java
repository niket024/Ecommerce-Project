package com.nik;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet extends HttpServlet 
{

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		String uname=request.getParameter("un");
		String pwd=request.getParameter("pw");
		if("abc".equals(uname) && "xyz".equals(pwd))
		{
			System.out.println("login success!");
			out.println("login success!<br>");
		System.out.println(uname);
		System.out.println(pwd);
		out.println(uname+"<br>");
		out.println(pwd);
		}
		else
		{
			System.out.println("login failed");
			out.println("login failed<br>");
			out.println("<a href='login.html'>try again?</a><br>");
		}
	}

}
