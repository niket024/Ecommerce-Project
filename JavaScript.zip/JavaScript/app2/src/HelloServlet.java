
import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

public class HelloServlet extends HttpServlet
{

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException 
			{
		
        PrintWriter out=response.getWriter();
        System.out.println("hello servlet");
        out.println("hello servlet");
	        }

}
