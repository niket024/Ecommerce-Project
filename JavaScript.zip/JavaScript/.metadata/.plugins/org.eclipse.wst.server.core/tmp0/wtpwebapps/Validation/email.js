function validateForm() 
{
	var f1 = document.forms[0];
	var em = f1.email;
	if (em.value.length == 0) {
		alert("This field should  must be filled out");
        
		var atpos = em.indexOf("@");
		var dotpos = em.lastIndexOf(".");
		if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= em.length) {
			alert("Not a valid e-mail address");
			return false;
		}
	}
	return true;
}