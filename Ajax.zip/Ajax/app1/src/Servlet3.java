import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Servlet3")
public class Servlet3 extends HttpServlet
{
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException ex)
		{
			ex.printStackTrace();
		}
		java.sql.Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		String state = request.getParameter("state");
		PrintWriter out = response.getWriter();
		try
		{
			con = DriverManager
					.getConnection("jdbc:oracle:thin:@localhost:1521:XE",
							"system", "great123");
			out.println("District:");
			out.println("<select name='district'>");
			out.println("<option value='0'>Select</option>");
			if ("bh".equals(state))
			{
				String sql = "select * from Bihar";

				stmt = con.createStatement();
				rs = stmt.executeQuery(sql);
				while (rs.next())
				{
					String s1 = rs.getString(2);

					out.println("<option value='si'>" + s1 + "</option>");
				}
			}
		} catch (SQLException ex)
		{
			ex.printStackTrace();
		}

		finally
		{
			try
			{
				if (con != null)
				{
					con.close();
					con = null;
				}
			} catch (SQLException ex)
			{
				ex.printStackTrace();
			}
			try
			{
				if (stmt != null)
				{
					stmt.close();
					stmt = null;
				}
			} catch (SQLException ex)
			{
				ex.printStackTrace();
			}
		}

	}

}
