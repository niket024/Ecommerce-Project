import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Servlet2")
public class Servlet2 extends HttpServlet
{
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException
	{
		String state = request.getParameter("state");
		PrintWriter out = response.getWriter();
		System.out.println("here");
		out.println("District:");
		out.println("<select name='district'>");
		out.println("<option value='0'>Select</option>");
		if ("bh".equals(state))
		
		{
			 out.println("<option value='sw'>Siwan</option>");
			 out.println("<option value='pt'>Patana</option>");
			 out.println("<option value='ch'>Chhapara</option>");
			 out.println("<option value='siv'>Shivahar</option>");

		}

		else if ("ra".equals(state))
		{
			out.println("<option value='si'>ppppp</option>");
			out.println("<option value='sw'>uuuu</option>");
			out.println("<option value='pt'>jayapur</option>");
			out.println("<option value='ch'>bikaner</option>");
			out.println("<option value='siv'>jaisalmer</option>");

		} else if ("pn".equals(state))
		{
			out.println("<option value='si'>qqqqqqq</option>");
			out.println("<option value='sw'>wwwwwwwww</option>");
			out.println("<option value='pt'>rrrrrrr</option>");
			out.println("<option value='ch'>tttttttt</option>");
			out.println("<option value='siv'>yyyyyyyy</option>");

		} else if ("hr".equals(state))
		{
			out.println("<option value='si'>aaaaa</option>");
			out.println("<option value='sw'>bbbbb</option>");
			out.println("<option value='pt'>cccc</option>");
			out.println("<option value='ch'>dddd</option>");
			out.println("<option value='siv'>eeee</option>");

		}

	}
	
}
