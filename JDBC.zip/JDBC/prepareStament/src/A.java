public class A
{
	static 
	{
		System.out.println("sib");
	}
	
}
