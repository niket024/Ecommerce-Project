
public class Manager
{
	
	public static void main(String[] args) throws Exception
	{
		Class.forName("A");
//		A a2=(A) c1.newInstance();
//		System.out.println(c1.getName());
//		System.out.println(c1.isInterface());
//		System.out.println(a1==a2);
		
		
	}
}
