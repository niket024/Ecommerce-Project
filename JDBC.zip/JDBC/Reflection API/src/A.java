
public class A
{

	String s1="";
	A()
	{
		System.out.println("cons1");
		s1="some security code";
	}
}
