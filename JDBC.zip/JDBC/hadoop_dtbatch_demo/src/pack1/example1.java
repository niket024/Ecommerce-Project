package pack1;

public class example1
{

}

file_>project-->name
project-->right click-->package
package-->class
class-->user defined template to create the variables and methods
object-->run time behaviour to the class

class is static
object is dynamic

object--->access the details of the class

