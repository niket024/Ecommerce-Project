package pack1;

public class example2
{

	public static void main(String[] args)
	{
		System.out.println("Welcome to Bigdata");

	}

}
