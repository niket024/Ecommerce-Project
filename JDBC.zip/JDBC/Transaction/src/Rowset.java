import java.sql.Connection;

import javax.sql.rowset.JdbcRowSet;
import javax.sql.rowset.RowSetProvider;

public class Rowset
{
	public static void main(String[] args) throws Exception
	{
		Connection con = DbUtil.getConnection();
		JdbcRowSet rowSet = RowSetProvider.newFactory().createJdbcRowSet();
		rowSet.setUrl("jdbc:oracle:thin:@localhost:1521:xe");
		rowSet.setUsername("JDBC");
		rowSet.setPassword("GREAT123");

		rowSet.setCommand("select * from HASSAN");
		rowSet.execute();
		while (rowSet.next()) 
		{
			  System.out.println("Id: " + rowSet.getString(1));  
              System.out.println("Name: " + rowSet.getString(2));  
		}
	}

}
