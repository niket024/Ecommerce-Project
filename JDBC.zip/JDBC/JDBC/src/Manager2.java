import java.sql.Connection;
import java.sql.Statement;

public class Manager2
{
public static void main(String[] args)
{
	try {
		Connection con=Util.getConnection();
		Statement stmt=con.createStatement();
		//String sql="insert into user values(45,'bbb')";
		//String sql="update user set name='xyz' where id=123";
		String sql="delete from user where id=45";
		stmt.executeUpdate(sql);
		stmt.close();
		con.close();
		System.out.println("done");
	} catch (Exception e) {
		e.printStackTrace();
	}
}
}
