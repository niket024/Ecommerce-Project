
public class Sib
{
	static 
	{
		System.out.println("sib");
	}

	public static void main(String[] args)
	{

	}
}
