import java.sql.Connection;
import java.sql.Statement;
import java.util.Scanner;

public class Manager3
{
	public static void main(String[] args) throws Exception
	{
		Connection con = Util.getConnection();
		Statement stmt = con.createStatement();
		String ch = "";
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("enter the id value");
			int id = sc.nextInt();
			System.out.println("enter the name");
			String name = sc.next();
			String sql = "insert into user values(" + id + ",'" + name + "')";
			stmt.executeUpdate(sql);
			System.out.println("do you want to continue?(y/n)");
			ch = sc.next();
		} while ("y".equalsIgnoreCase(ch));
		System.out.println("thank you!!");
	}
}
