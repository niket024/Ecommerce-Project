package com.nik;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Manager
{
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) throws Exception
	{
		Connection con = DbUtil.getConnection();
		System.out.println("**************Employee Details****************");
		System.out.println("1.Add");
		System.out.println("2.Update");
		System.out.println("3.Delete");
		System.out.println("4.Display");
		System.out.println("5.Exit");
		Scanner sc = new Scanner(System.in);
		System.out.println("Ener your choice?");
		int ch = sc.nextInt();
		switch (ch) {
		case 1:
			addEmployee(con);
			break;
		case 2:
			updateEmployee();
			break;
		case 3:
			delEmployee();
			break;
		case 4:
			displayEmployee();
			break;
		case 5:
			System.out.println("Thank you!!");
			System.exit(0);
			break;
		default:
			System.out.println("please enter the crrect choice");
			break;
		}
	}

	static void addEmployee(Connection con) throws Exception
	{

		String sql = "insert into emp values (?,?,?,?)";
		PreparedStatement pstmt = con.prepareStatement(sql);
		System.out.println("enter your id");
		int id = sc.nextInt();
		System.out.println("enter name");
		String name = sc.next();
		System.out.println("enter age");
		int age = sc.nextInt();
		System.out.println("enter your salary");
		int sal = sc.nextInt();
		pstmt.setInt(1, id);
		pstmt.setString(2, name);
		pstmt.setInt(3, age);
		pstmt.setInt(4, sal);
		int i = pstmt.executeUpdate();
		if (i > 0)
		{
			System.out.println("employee added successfully");
		} else 
		{
			System.out.println("Oops! something went wrong");
		}
	}

	static void updateEmployee()
	{
		System.out.println("update");
	}

	static void delEmployee()
	{
		System.out.println("delete");
	}

	static void displayEmployee()
	{
		System.out.println("select");
	}
}
