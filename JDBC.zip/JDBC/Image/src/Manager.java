import java.sql.Connection;
import java.sql.Statement;

public class Manager
{
	public static void main(String[] args) throws Exception
	{
		Connection con = DbUtil.getConnection();
		String sql = "create table picture (sno int,image blob)";// binary large object													// object
		Statement stmt = con.createStatement();
		stmt.execute(sql);
		System.out.println("done");
	}
}
