package nik;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class View
{
 public static void main(String[] args) throws Exception
{
	Connection con=DbUtil.getConnection();
	Statement stmt=con.createStatement();
	String sql="select * from emp";
	ResultSet rs=stmt.executeQuery(sql);
	while(rs.next())
	{
		System.out.println(rs.getInt(1));
		System.out.println(rs.getString(2));
		System.out.println(rs.getInt(3));
		System.out.println(rs.getInt(4));
		System.out.println("----------------------");
	}
}
}
