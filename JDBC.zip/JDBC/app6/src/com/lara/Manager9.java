package com.lara;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
public class Manager9
{
public static void main(String[] args)
{
	Connection con=null;
	PreparedStatement pstmt=null;
	try
	{
		con=DbUtil.getConnection();
		pstmt=con.prepareStatement("insert into pooja values(501,'abc')");
		pstmt.executeUpdate();
		System.out.println("done");
		
	}
	catch(SQLException ex)
	{
	ex.printStackTrace();
	}
	finally
	{
		DbUtil.closeAll(null, pstmt, con);
	}
}
}
