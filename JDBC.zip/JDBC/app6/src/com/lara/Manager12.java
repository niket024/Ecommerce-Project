package com.lara;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Manager12
{
	public static void main(String[] args)
	{
		Connection con=null;
		PreparedStatement pstmt=null;
		try
		{
			con=DbUtil.getConnection();
			pstmt=con.prepareStatement("insert into pooja values(?,?)");
			Scanner sc=new Scanner(System.in);
			String name,decider;
			int id;
			do
			{
				System.out.println("enter id");
				id=sc.nextInt();
				System.out.println("enter the name");
				name=sc.next();
				pstmt.setInt(1, id);
				pstmt.setString(2, name);
				pstmt.executeUpdate();
				System.out.println("do u want insert again(y/n)");
				decider=sc.next();
			} while ("y".equals(decider));
		}
		catch(SQLException ex)
		{
		ex.printStackTrace();
		}
		finally
		{
			Manager3.closeAll(null, pstmt, con);
		}
	}

}
