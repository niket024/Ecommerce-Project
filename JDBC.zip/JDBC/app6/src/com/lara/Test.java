package com.lara;

public class Test
{
	public static void main(String[] args)
	{
		int i=-111;
		int j=222;
		j=i--;
		System.out.println(j);
		System.out.println(i);
	}
}
