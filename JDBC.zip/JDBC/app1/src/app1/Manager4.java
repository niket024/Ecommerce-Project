package app1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Manager4
{
	public static void main(String[] args) throws Exception
	{
		Class.forName("org.h2.Driver");
		Connection con = DriverManager
				.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");
		Statement stmt = con.createStatement();
		String sql = "Select * from pooja";
		ResultSet rs = stmt.executeQuery(sql);
		while (rs.next()) 
		{
			System.out.println("id=" + rs.getInt(1));
			System.out.println("name=" + rs.getString(2));
			System.out.println("------------------");
		}
	}
}
