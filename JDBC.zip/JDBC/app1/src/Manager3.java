import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class Manager3
{
	public static void main(String[] args) throws Exception
	{
		Class.forName("org.h2.Driver");
		Connection con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","sa","");
		Statement stmt=con.createStatement();
		String sql="select * from pooja";
		ResultSet rs=stmt.executeQuery(sql);
		FileWriter fout=new FileWriter("output.xls");
		while(rs.next())
		{
			System.out.println(rs.getInt("id"));
			System.out.println(rs.getString(2));
			fout.write("Id="+rs.getInt("id")+"\n");
			fout.write("Name="+rs.getString("name")+"\n");
			
			System.out.println("------------------");
		}
		fout.flush();
		fout.close();
		System.out.println("done");
	}
}
