import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;


public class Manager2
{
	public static void main(String[] args) throws Exception
	{
		Class.forName("org.h2.Driver");
		Connection con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","sa","");
		Statement stmt=con.createStatement();
		//PreparedStatement pstmt=con.prepareStatement("insert into pooja values(?,?)");
//		pstmt.setInt(1, 123);
//		pstmt.setString(2, "ravi");
		String sql="insert into pooja values(45,'nnn')";
		//String sql="UPDATE  POOJA SET NAME='POOJA' WHERE ID=8";
		//String sql="DELETE FROM  POOJA  WHERE ID=45";
		stmt.executeUpdate(sql);
		System.out.println("done");
	}
}
