import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Manager1
{
	public static void main(String[] args) throws Exception
	{
		Class.forName("org.h2.Driver");
		Connection con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","sa","");
		Statement stmt=con.createStatement();
		String sql = "create table pooja (id int ,name varchar(20))";
		stmt.execute(sql);
		stmt.close();
		con.close();
		System.out.println("done");
	}
}
