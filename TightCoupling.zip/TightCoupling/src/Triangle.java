
public class Triangle implements Area
{
		public void getArea()
		{
			System.out.println("triangle area");
		}
}
