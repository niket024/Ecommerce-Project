
public class Rectangle implements Area 
{
	public void getArea()
	{
		System.out.println("recatangle area");
	}
}
