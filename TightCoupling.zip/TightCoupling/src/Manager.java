class Area1
{
	public void getArea(String name)
	{
		if(name.equals("triangle"))
		{
			new Triangle().getArea();
		}
		if(name.equals("rectangle"))
		{
			new Rectangle().getArea();
		}
		if(name.equals("square"))
		{
			new Square().getArea();
		}
		if(name.equals("circle"))
		{
			new Cirlce().getArea();
		}
	}
}
public class Manager {
	public static void main(String[] args) {
		Area1 a1=new Area1();
		a1.getArea("triangle");
		a1.getArea("rectangle");
		a1.getArea("square");
		a1.getArea("circle");
		
				
	}
}
