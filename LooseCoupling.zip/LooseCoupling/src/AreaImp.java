
public class AreaImp {
	
	public static void getArea(Area a1)
	{
		a1.getArea();
	}
	
	public static void main(String[] args) {
		Area a2=new Triangle();
		getArea(a2);
		a2=new Rectangle();
		getArea(a2);
		a2=new Square();
		getArea(a2);
		a2=new Circle();
		getArea(a2);
	}
}
