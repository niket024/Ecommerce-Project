
public interface Area {
	void getArea();
}
