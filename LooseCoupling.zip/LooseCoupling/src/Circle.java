
public class Circle implements Area {
	@Override
	public void getArea() {
		System.out.println("circle area");

	}
}
