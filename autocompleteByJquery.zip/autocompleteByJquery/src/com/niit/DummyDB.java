package com.niit;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.StringTokenizer;

public class DummyDB {
	private int totalCountries;
	private String data = "";
			
	private List<String> countries;
	public DummyDB() {
		try {
			File f1=new File("F:\\ShoppingCart\\autocompleteByJquery\\countries.txt");
			FileReader fr=new  FileReader(f1);
			BufferedReader br=new BufferedReader(fr);
			String s1=br.readLine();
			while(s1!=null){
				data=data+s1+",";
				s1=br.readLine();
			}
			System.out.println(data);
			br.close();
			fr.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		countries = new ArrayList<String>();
		StringTokenizer st = new StringTokenizer(data, ",");
		
		while(st.hasMoreTokens()) {
			countries.add(st.nextToken().trim());
		}
		totalCountries = countries.size();
	}
	
	public List<String> getData(String query) {
		String country = null;
		query = query.toLowerCase();
		List<String> matched = new ArrayList<String>();
		for(int i=0; i<totalCountries; i++) {
			country = countries.get(i).toLowerCase();
			if(country.startsWith(query)) {
				matched.add(countries.get(i));
			}
		}
		return matched;
	}
}