package com.niit.shoppingcart.dao;

import com.niit.shoppingcart.model.UserOrder;

public interface UserOrderDAO {
	
	public void saveOrUpdate(UserOrder userOrder);

	
	

}
