package example;

import java.util.ArrayList;

public class Manager
{
	public static void main(String[] args)
	{
		ArrayList<Employee> empList = new ArrayList<Employee>();
		Employee emp = null;
		for (int i = 0; i < 3; i++)
		{
			emp = new Employee();
			emp.setId(123);
			emp.setName("abc");
			emp.setAge(23);
			empList.add(emp);//

		}
		for (int i = 0; i < empList.size(); i++)
		{
			Employee emp1 = empList.get(i);
			System.out.println(emp1.getId());
			System.out.println(emp1.getName());
			System.out.println(emp1.getAge());
			System.out.println("---------------");
		}
	}
}
