package set;

import java.util.TreeSet;

public class Manager5
{
	public static void main(String[] args)
	{
       TreeSet set=new TreeSet();
       set.add(23);
       set.add(89);
       set.add(7);
       set.add(45);
       set.add(8888);
       set.add(23);
       System.out.println(set);
	}
}
