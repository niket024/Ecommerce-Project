package vector;

import java.util.Vector;

public class A
{
	public static void main(String[] args)
	{
		Vector list = new Vector();
		list.add(123);
		list.add("abd");
		list.add(123.90);
		list.add('c');
		list.add(true);
		list.add(23);
		list.add(88888888l);
		list.add(33.33f);
		System.out.println(list);
	}
}
