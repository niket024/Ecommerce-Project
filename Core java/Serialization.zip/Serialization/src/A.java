import java.io.Serializable;

public class A implements Serializable
{
	transient int i;
	long l;
    double d;
	Character ch;
	boolean b1;
	
}
