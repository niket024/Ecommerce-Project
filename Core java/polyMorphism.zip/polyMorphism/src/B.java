public class B extends A
{
	int i = 20;

	void test()
	{
		System.out.println("test-B");
	}
}
