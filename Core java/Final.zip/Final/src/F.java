public interface F
{
	public final int i=90;
	int j=78;
}
