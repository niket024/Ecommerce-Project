public class A
{
	static final int i=90;

	
	public static void main(String[] args)
	{
		A a1 = new A();
		//a1.i=20;
		System.out.println(a1.i);
	}
}
