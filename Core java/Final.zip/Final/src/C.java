public class C extends B
{

	void test()
	{
		// TODO Auto-generated method stub
		// super.test();
	}
}
