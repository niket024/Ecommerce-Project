public class B
{
	int i;

	final void test()
	{

	}
}
