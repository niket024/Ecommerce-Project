
public class D
{
public static void main(String[] args)
{
	System.out.println("main1");
	main(89);
}

	public static void main(int i)
	{
		System.out.println("main2");
	}
}
