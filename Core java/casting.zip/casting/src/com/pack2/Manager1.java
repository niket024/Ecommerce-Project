package com.pack2;

public class Manager1
{
public static void main(String[] args)
{
	A a1=new D();
	System.out.println(a1 instanceof Object);
	System.out.println(a1 instanceof A);
	System.out.println(a1 instanceof B);
	System.out.println(a1 instanceof C);
	System.out.println(a1 instanceof D);
	
}

}
