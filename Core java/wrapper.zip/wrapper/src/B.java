public class B
{
	public static void main(String[] args)
	{
		Double d1 = new Double(12.90);
		double d2 = d1.doubleValue();
		System.out.println("done");
	}
}
