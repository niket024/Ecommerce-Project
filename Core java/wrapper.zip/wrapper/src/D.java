public class D
{
	public static void main(String[] args)
	{
		String s1 = "abc";
		Integer obj = new Integer(s1);
	    int i = obj.intValue();
		Double obj2 = new Double(s1);
		double d1 = obj2.doubleValue();
		System.out.println("done");
	}
}
