package AList.realtimeexample;

import java.util.ArrayList;
import java.util.Scanner;

public class Manager
{
	static Scanner sc = new Scanner(System.in);
	static ArrayList<Employee> empList= new ArrayList<Employee>();
	public static void main(String[] args)
	{
		String ch = "";
		int choice;
		do
		{
			System.out.println("****Employee management******");
			System.out.println("1.Create");
			System.out.println("2.Update");
			System.out.println("3.Delete");
			System.out.println("4.Display");
			System.out.println("5.Exit");
			System.out.println("please enter your choice(1-5)");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				create();
				break;
			case 2:
				update();
				break;
			case 3:
				delete();
				break;
			case 4:
				display();
				break;
			case 5:
				System.exit(0);
				System.out.println("thanks!!!!");
				break;
			default:
				System.out.println("please enter the choice from 1-5 only");
				break;
			}
			System.out.println("do you wnat to continue?(Y/N)");
			ch=sc.next();
		} while (ch.equalsIgnoreCase("y"));
	}

	private static void display()
	{
		System.out.println("***Employee Details****");
		for(Employee emp:empList)
		{
			System.out.println("Id="+emp.getId());
			System.out.println("Fname="+emp.getFname());
			System.out.println("Lname="+emp.getLname());
			System.out.println("Age="+emp.getAge());
			System.out.println("Address="+emp.getAddress());
			System.out.println("--------------------------");
		}
		
	}

	private static void delete()
	{
		System.out.println("under construction");
		
	}

	private static void update()
	{
		System.out.println("under construction");
		
	}

	private static void create()
	{
		Employee emp=new Employee();
		System.out.println("enter the id");
		int id = sc.nextInt();
		System.out.println("enter the fname");
		String fname = sc.next();
		System.out.println("enter the lname");
		String lname = sc.next();
		System.out.println("enter the age");
		int age = sc.nextInt();
		System.out.println("enter the address");
		String address = sc.next();
		emp.setId(id);
		emp.setFname(fname);
		emp.setLname(lname);
		emp.setAge(age);
		emp.setAddress(address);
		empList.add(emp);
		System.out.println("employee has added successfully!!!!");

	}
}
