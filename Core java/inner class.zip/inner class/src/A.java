public class A
{
	static class B
	{
		int i=90;
	}
	public static void main(String[] args)
	{
		A.B b1=new A.B();
		System.out.println(b1.i);
	}
}
