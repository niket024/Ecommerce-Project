public abstract class H
{
	abstract void test();
}
