package pack1;

public class A
{
	public static void main(String[] args) throws ArithmeticException
	{
		System.out.println("main1");
		int i = 10 / 0;
		System.out.println("main2");
		System.out.println("main2");
		System.out.println("main2");
		System.out.println("main2");
		System.out.println("main2");
	}
}
