package pack2;

public class Checked1
{
	public static void main(String[] args) throws InterruptedException
	{
		Thread.sleep(10000);
	}
}
