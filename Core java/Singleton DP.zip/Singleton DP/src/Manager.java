public class Manager
{
	public static void main(String[] args)
	{
		A a1 = A.getObject();
		a1.test();
		B b1=B.getObject();
		b1.test();
	}
}
