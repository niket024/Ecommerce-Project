package example.crud;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Manager
{
	static Scanner sc = new Scanner(System.in);
	static List<Student> studentList = new ArrayList<Student>();

	public static void main(String[] args)
	{
		String ch = "";
		do
		{
			System.out.println("******Studentn Management******");
			System.out.println("1.Add");
			System.out.println("2.Update");
			System.out.println("3.Delete");
			System.out.println("4.Read");
			System.out.println("5.Exit");
			System.out.println("Enter your choice(1-5)");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				addStudent();
				break;
			case 2:
				updateStudent();
				break;
			case 3:
				deleteStudent();
				break;
			case 4:
				readStudent();
				break;
			case 5:
				System.exit(0);
				break;

			default:
				System.out.println("Please enter the valid number");
				break;
			}
			System.out.println("Do you want to continue?(y/n)");
			ch = sc.next();
		} while (ch.equalsIgnoreCase("y"));
		System.out.println("Thank you!!!");
	}

	private static void readStudent()
	{
		System.out.println("No of Student : " + studentList.size());
		for (Student student : studentList)
		{
			System.out.println("Roll No="+student.getRollNo());
			System.out.println("Firstname="+student.getFname());
			System.out.println("Lastname="+student.getLname());
			System.out.println("Age="+student.getAge());
			System.out.println("----------------------");
		}

	}

	private static void deleteStudent()
	{
		System.out.println("Enter the roll no which you want to delete");
		int roll = sc.nextInt();
		boolean flag = false;
		Iterator<Student> iterator = studentList.iterator();
		while(iterator.hasNext())
		{
			int rollNo = iterator.next().getRollNo();
			if(roll == rollNo)
			{
				flag = true;
				iterator.remove();
			}
		}
		if(flag)
		{
			System.out.println("Student deleted successfully!!");
			readStudent();
		}
		else
		{
			System.out.println("Given roll no is not available");
		}

	}

	private static void updateStudent()
	{
		System.out.println("under construction...");

	}

	private static void addStudent()
	{
		System.out.println("Enter the no of Student");
		int no = sc.nextInt();
		Student student = null;
		for (int i = 0; i < no; i++)
		{
			student = new Student();
			System.out.println("Enter the roll no");
			student.setRollNo(sc.nextInt());
			System.out.println("Enter the fname");
			student.setFname(sc.next());
			System.out.println("Enter the lanme");
			student.setLname(sc.next());
			System.out.println("Enter the age");
			student.setAge(sc.nextInt());
			studentList.add(student);
			System.out.println((i+1)+" Studen Added");
			System.out.println("----------------");
		}
		System.out.println("All Student Added Successfully!!!!");
	}

}
