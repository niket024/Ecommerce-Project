public abstract class C extends A
{
	abstract void test3();
	
}
