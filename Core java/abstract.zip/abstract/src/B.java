public class B extends A
{

	
	void test()
	{
		// TODO Auto-generated method stub
		
	}

	
	void test2()
	{
		// TODO Auto-generated method stub
		
	}
   
}
