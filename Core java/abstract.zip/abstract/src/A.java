abstract class A
{
	abstract void test();
	abstract void test2();

	void test1()
	{
		
	}
	
	
}
