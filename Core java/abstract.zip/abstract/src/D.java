
public  class D extends C
{

	@Override
	void test3()
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	void test()
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	void test2()
	{
		// TODO Auto-generated method stub
		
	}

	
	
}
