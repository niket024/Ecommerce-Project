
public class C extends A
{
	public static void main(String[] args)
	{
		C c1 = new C();
		System.out.println(c1.i);
		c1.test();
		c1.test1();
	}
}
