public class A
{

	public static void main(String[] args)
	{
		System.out.println("main1");
		//assert false ;//simple 
		assert false : "your progarm is going to be terminated due to some bussiness logic";

		System.out.println("main2");

	}
}
