public class B implements A,C
{
	public void test()
	{
		
	}
	public void test1()
	{
		
	}

	public void test3()
	{
		
		
	}
}
