package example;

public class CITI implements RBI
{
	@Override
	public int getROI()
	{
		System.out.println("i m from citi");
		return 9;
	}
}
