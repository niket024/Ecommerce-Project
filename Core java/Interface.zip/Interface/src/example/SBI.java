package example;

public class SBI implements RBI
{
	@Override
	public int getROI()
	{
		System.out.println("i m from SBI");
		return 7;
	}
}
