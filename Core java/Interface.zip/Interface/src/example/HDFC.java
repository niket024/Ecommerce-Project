package example;

public class HDFC implements RBI
{
	@Override
	public int getROI()
	{
		System.out.println("I am from HDFC");
		return 8;
	}
}
