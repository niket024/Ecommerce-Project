public class Manager
{
	public static void main(String[] args)
	{
		System.out.println("***********two wheeler details*********");
		TwoWheeler t1 = new TwoWheeler();
		t1.cost();
		t1.speed();
		System.out.println("**************FourWheeler Detaild**************");
		FourWheeler f1 = new FourWheeler();
		f1.cost();
		f1.speed();
	}
}
