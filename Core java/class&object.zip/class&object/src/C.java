public class C
{
	static void test()
	{
		System.out.println("test");
	}

	void test1()
	{
		System.out.println("test1");
	}

	public static void main(String[] args)
	{
		C c1=new C();
		C.test();
		c1.test1();
		System.out.println("main");
	}
}
