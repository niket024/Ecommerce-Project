public class B
{
	static double i ;
	public static void main(String[] args)
	{
		int i = 20;
		System.out.println(B.i);
	}
}
