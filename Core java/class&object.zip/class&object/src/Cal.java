public class Cal
{
	void add()
	{
		int a=10;
		int b=20;
		int sum=a+b;
		System.out.println("sum="+sum);
	}
	void sub(int a,int b)
	{
		int sub=a-b;
		System.out.println("sub="+sub);
	}
	int mul()
	{
		int a=10;
		int b=20;
		int mul=a*b;
		return mul;
	}
	int div(int a,int b)
	{
		int div=a/b;
		return div;
	}
	public static void main(String[] args)
	{
		System.out.println("*****CALCULATOR*******");
		Cal c1=new Cal();
		
		c1.sub(20, 10);
		int mul=c1.mul();
		System.out.println("mul="+mul);
		int div=c1.div(100, 5);
		System.out.println("div="+div);
	}
}
