public class A
{
	static int i = 10;
	int j = 20;
	static void test()
	{
		System.out.println("test");	
	}
	void test1()
	{
		System.out.println("test1");
	}
	public static void main(String[] args)
	{
		A a1=new A();
		System.out.println(A.i);
		System.out.println(a1.j);
		A.test();
		a1.test1();
	}
}
