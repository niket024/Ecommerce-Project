public class B
{
	public static void main(String [] arg)
	{
		// int x[]=new int [10];
	/// int[]      x=new int[10];
	// int [] x=new int [90];
		int[] x = { 12, 34, 45, 67, 89,77 };
		for (int i : x)
		{
			System.out.println(i);
		}
		System.out.println(x[78]);
		System.out.println("Length="+x.length);
	}
}
