import java.util.Scanner;

public class A
{
	public static void main(String[] args)
	{
		
		int x[] = new int[5];
//		x[0]=11;
//		x[1]=22;
		Scanner sc = new Scanner(System.in);
		for (int i = 0; i < x.length; i++)
		{
			System.out.println("enter the no:" + i+"th");
			x[i] = sc.nextInt();
		}
		for (int i = 0; i <x.length; i++)
		{
			System.out.println(x[i]);
		}
		System.out.println("\n------------");
		// Enhanced or for-each loop jdk1.5
		for (int j : x)
		{
			System.out.print(j+",");
		}
//		System.out.println("\n"+x.length);
	}

}
