public class D
{
	public static void main(String[] args)
	{
		int x[] = new int[3];
		x[0] = 10;
		System.out.println(x.toString());
		System.out.println(x[0]);
		x = new int[5];
		x[0] = 20;
		System.out.println(x);
		System.out.println(x[0]);

	}
}
// [I