import java.util.Arrays;

public class E
{
	public static void main(String[] args)
	{
		int y[] = { 12, 34, 45, 67, 67, 55, 44, 33 };
		System.out.println(Arrays.toString(y));

	}

}
