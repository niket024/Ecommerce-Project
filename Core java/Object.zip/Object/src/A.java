
public class A
{
	int i = 20;
	int j = 45;
	int k = 34;

	public static void main(String[] args)
	{
		A a1 = new A();
		A a2 = new A();
		A a3 = a2;
		System.out.println(a1.toString());
		System.out.println(a2.toString());
		System.out.println(a3.toString());
	}

	@Override
	public String toString()
	{

		return "i=" + i + ",j=" + j + ",k=" + k;
	}
}
