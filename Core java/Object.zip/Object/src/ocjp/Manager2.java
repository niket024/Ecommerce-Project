package ocjp;

public class Manager2
{
public static void main(String[] args)
{
	Manager2 m1=new Manager2();
	
	System.out.println(m1.toString());
 
	System.out.println(m1);
}

}
