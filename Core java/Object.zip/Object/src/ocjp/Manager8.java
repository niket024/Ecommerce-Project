package ocjp;
class U
{
	int i;
	U(int i)
	{
		this.i=i;
	}
	@Override
	public String toString()
	{
		
		return "i="+i;
	}
}
public class Manager8
{
public static void main(String[] args)
{
	System.out.println(12);
}
}
