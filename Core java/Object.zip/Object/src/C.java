public class C
{
	int i = 90;

	public static void main(String[] args) 
	{
		C c1 = new C();
		
		System.out.println(c1.hashCode());
		System.out.println(c1.getClass());
	}
}
