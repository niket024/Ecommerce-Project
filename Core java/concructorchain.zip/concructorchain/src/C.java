public class C extends B
{
	C()
	{
		System.out.println("c-cons1");
	}

	public static void main(String[] args)
	{
		C c1 = new C();
	}
}
