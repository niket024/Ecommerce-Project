public class A
{
	A()
	{
		this(12);
		System.out.println("a-cons1");
	}

	A(int i)
	{
		
		System.out.println("a-cons2");
	}

	public static void main(String[] args)
	{
		A a1 = new A();
		
	}
}
