public class Use extends Object
{
	int accno;
	int mob;

	Use(int i, int j)
	{
		super();
		accno=i;
		mob=j;
	}
}
