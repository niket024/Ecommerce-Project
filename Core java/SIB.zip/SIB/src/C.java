
public class C
{
	static int i;
	int j;
  static
  {
	  i=90;
	 // j=90;
	  int a=67;
	  int b=4;
	  int c=a+b;
	  System.out.println(c);
	System.out.println("hello world!");  
  }
  
  {
	  System.out.println(j=90);
  }
  public static void main(String[] args)
{
	
}
}
