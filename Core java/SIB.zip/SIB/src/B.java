public class B
{
	

	public static void main(String[] args)
	{
		System.out.println("main");
	}
	
	static
	{
		System.out.println("sib1");
	}
}
