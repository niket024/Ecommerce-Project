package AList.realtimeexample;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Manager
{
	static Scanner sc = new Scanner(System.in);
	static ArrayList<Employee> empList = new ArrayList<Employee>();

	public static void main(String[] args)
	{
		String choice = "";
		do
		{
			System.out.println("****Employee management****");
			System.out.println("1.Add");
			System.out.println("2.Update");
			System.out.println("3.Remove");
			System.out.println("4.Display");
			System.out.println("5.Exit");
			System.out.println("Enter your choice(1-5)");
			int ch = sc.nextInt();
			switch (ch) {
			case 1:
				addEmployee();
				break;
			case 2:

				break;
			case 3:
				removeEmployee();
				break;
			case 4:
				displayEmployee();
				break;
			case 5:

				break;

			default:
				System.out.println("Please give the right choice");
				break;
			}
			System.out.println("Do you want to continue?(y/n)");
			choice = sc.next();
		} while ("y".equalsIgnoreCase(choice));
		System.out.println("Thanks!!!!!!");
	}

	private static void removeEmployee()
	{
		System.out.println("enter the id which you want to remove");
		int id = sc.nextInt();
		Iterator<Employee> emp1 = empList.iterator();
		boolean flag=false;
		while (emp1.hasNext())
		{
			int id1 = emp1.next().getId();
			if (id == id1)
			{
				flag = true;
				emp1.remove();
			}

		}
		if(flag)
		{
			System.out.println("Employee removed successfully");
		}
		else
		{
			System.out.println("Employee not existing");
		}

	}

	private static void displayEmployee()
	{
		for (Employee emp : empList)
		{
			System.out.println("Id=" + emp.getId());
			System.out.println("Fname=" + emp.getfName());
			System.out.println("Lname=" + emp.getlName());
			System.out.println("Age=" + emp.getAge());
			System.out.println("----------------------");
		}
	}

	private static void addEmployee()
	{
		Employee emp = new Employee();
		System.out.println("****Add Employee*****");
		System.out.println("Enter the id");
		int id = sc.nextInt();
		// emp.setId(sc.nextInt());
		System.out.println("Enter the fname");
		String fName = sc.next();
		System.out.println("Enter the lname");
		String lName = sc.next();
		System.out.println("Enter the age");
		int age = sc.nextInt();
		emp.setId(id);
		emp.setfName(fName);
		emp.setlName(lName);
		emp.setAge(age);
		empList.add(emp);
		System.out.println("Employee added Sucessfully!!!!");
	}

}
