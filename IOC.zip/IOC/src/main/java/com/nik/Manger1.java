package com.nik;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Manger1 {
private static ApplicationContext context;

public static void main(String[] args) {
	context = new AnnotationConfigApplicationContext(StudentConfig.class);
	Student s1=context.getBean(Student.class);
	System.out.println(s1.getMessage());
	s1.myDestroy();
}
}
