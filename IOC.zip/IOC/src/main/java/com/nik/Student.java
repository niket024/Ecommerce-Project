package com.nik;

public class Student {
	public String getMessage(){
		return "Hello Spring";
	}
	public void myInit(){
		System.out.println("init");
	}
	public void myDestroy(){
		System.out.println("destroy");
	}
}
