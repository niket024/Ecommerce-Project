package ReqAttributeMgmt;

import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;

public class SessionAttributeMgmt implements HttpSessionAttributeListener
{
	@Override
	public void attributeAdded(HttpSessionBindingEvent arg0)
	{
		System.out.println("sesseion attribute added");

	}

	@Override
	public void attributeReplaced(HttpSessionBindingEvent arg0)
	{
		System.out.println(" sesseion attribute replaced");

	}

	@Override
	public void attributeRemoved(HttpSessionBindingEvent arg0)
	{
		System.out.println("sesseion attribute removed");

	}
}
