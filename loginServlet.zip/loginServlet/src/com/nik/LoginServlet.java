package com.nik;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 public LoginServlet() {
	        super();
	        // TODO Auto-generated constructor stub
	    }

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());

		String uname = request.getParameter("uname");
		String pwd = request.getParameter("pwd");
		PrintWriter out = response.getWriter();
		if ("admin".equals(uname) && "xyz".equals(pwd)) {
			response.sendRedirect("success.html");
		} else {
			out.println("<html><body>Login is failed!!<br><a href='login.html'>Pls try again</a></body></html>");
		}

	}

}
