package com.nik;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegistartionServlet extends HttpServlet
{
	private static final long serialVersionUID = -5584361032933449306L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter out = response.getWriter();
		String fname = request.getParameter("fname");
		String lname = request.getParameter("lname");
		String uname = request.getParameter("uname");
		String pwd = request.getParameter("pwd");
		int status = RegistrationDAO.registerUser(fname, lname, uname, pwd);
		if (status > 0)
		{
			out.println("Your registration is success!!!!");
		}
		else
		{
			out.print("Oops! your registration is failed due to network issue");
		}

	}

}
