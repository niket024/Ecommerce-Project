package com.nik;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;

public class RegistrationDAO
{
	public static int registerUser(String fname, String lname, String uname,
			String pwd)
	{
		Random random = new Random();
		int regId = random.nextInt(50) + 1;

		String sql = "insert into REGLOGIN values(" + regId + ",'" + fname
				+ "','" + lname + "','" + uname + "','" + pwd + "')";
		System.out.println(sql);
		int status = 0;
		Statement stmt = null;
		Connection con = null;
		try
		{
			con = getConnection();
			stmt = con.createStatement();
			status = stmt.executeUpdate(sql);
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		return status;
	}

	private static Connection getConnection()
	{
		try
		{
			Class.forName("org.h2.Driver");
		} catch (ClassNotFoundException ex)
		{
			ex.printStackTrace();
		}
		Connection con = null;
		try
		{
			con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test",
					"sa", "");

		} catch (SQLException ex)
		{
			ex.printStackTrace();
		}
		return con;
	}

	public static boolean validateUser(String uname, String pwd)
	{
		boolean status = false;
		String sql = "select * from REGLOGIN where user_name='" + uname
				+ "' and password ='" + pwd + "'";
		try
		{
			Connection con = getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			status = rs.next();
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		return status;
	}
}
