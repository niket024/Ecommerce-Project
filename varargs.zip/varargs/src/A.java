public class A
{
	void test(double d, int... i)
	{
		for (int j : i)
		{
			System.out.println(j);
		}
		System.out.println("test");
	}

	public static void main(String... args)
	{
		A a1 = new A();
		a1.test(23.45, 3, 5, 6, 7, 7);
	}
}
