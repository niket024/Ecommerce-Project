package main.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import main.java.Add;

public class TestAdd {

	int n;

	@BeforeClass
	public static void beforeClass(){
		System.out.println("before class execute...we can write code like db connection");
	}
	@Before
	public void setUp() {
		System.out.println("before test method");
		n = 12;
	}

	@Test
	public void test() {
		Add a1 = new Add();
		assertEquals(n, a1.add(7, 5));

	}

	@After
	public void after() {
		
		System.out.println("after test method call");
	}
	@AfterClass
	public static void afterClass() {
		System.out.println("after class...her we write code like db close etc");
	}

}
