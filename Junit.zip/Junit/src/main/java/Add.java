package main.java;

public class Add {
	public int add(int a, int b) {
		return a + b;
	}
}
