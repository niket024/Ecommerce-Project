package com.pack1;

public class Hello
{
	public String sayHello()
	{
		return "hello to all";
	}
}
