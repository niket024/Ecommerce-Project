package com.nik.dao;

import java.util.List;

import com.nik.model.Product;

public interface ProductDao {
	List<Product> list();
}
