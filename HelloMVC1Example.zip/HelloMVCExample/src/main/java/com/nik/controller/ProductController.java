package com.nik.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nik.dao.ProductDao;

@Controller
public class ProductController {
	@Autowired(required = true)
	private ProductDao productDAO;
	@RequestMapping("/getProduct")
	public String Listproduct(Model model) {
		model.addAttribute("productList", this.productDAO.list());
		return "product";
	}

}
