package com.nik.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nik.dao.ProductDao;
import com.nik.dao.UserDemoDao;
import com.nik.model.UserDemo;

@Controller
public class HelloController {
	@Autowired(required = true)
	private ProductDao productDAO;
	@Autowired(required = true)
	private UserDemoDao userDemoDao;

	@RequestMapping("/")
	public String setUpForm(Map<String, Object> map) {

		return "index";
	}

	@RequestMapping("/index")
	public String loginForm(Map<String, Object> map) {

		return "login";
	}

	@RequestMapping("/register")
	public String regForm(Map<String, Object> map) {

		return "register";
	}
	@RequestMapping("/contactUs")
	public String getContact(Map<String, Object> map) {

		return "contactUs";
	}
	@RequestMapping("/getregister")
	public String regFormSubmit(HttpServletRequest req, HttpServletResponse res) {
		String fname = req.getParameter("first_name");
		String lname = req.getParameter("last_name");
		String email = req.getParameter("email");
		String uname = req.getParameter("uname");
		String pwd = req.getParameter("password");
		UserDemo uDemo = new UserDemo();
		uDemo.setId(125);
		uDemo.setFirstName(fname);
		uDemo.setLastName(lname);
		uDemo.setEmail(email);
		uDemo.setUserName(uname);
		uDemo.setPassword(pwd);
		userDemoDao.saveUser(uDemo);
		return "login";
	}

	@RequestMapping("/login")
	public ModelAndView getLoginCheck(HttpServletRequest req, HttpServletResponse res) {
		String uname = req.getParameter("uname");
		String pwd = req.getParameter("pwd");
		ModelAndView mav = new ModelAndView();
		if (uname.equals("abc") && pwd.equals("xyz")) {
			mav.addObject("productList", this.productDAO.list());
			mav.setViewName("product");

		} else {
			mav.setViewName("loginFailed");

		}
		return mav;
	}
}
