package com.nik.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nik.dao.ProductDao;

@Controller
public class ProductController {
	@Autowired(required = true)
	private ProductDao productDAO;
	@RequestMapping("/getProduct")
	public String Listproduct(Model model) {
		model.addAttribute("productList", this.productDAO.list());
		return "product";
	}

	@RequestMapping("/addprodct")
	public ModelAndView saveProduct(HttpServletRequest req, HttpServletResponse res) {
		String productName = req.getParameter("productName");
		String productDesc = req.getParameter("productDesc");
		String productPrice = req.getParameter("productPrice");
		ModelAndView model = new ModelAndView();
		model.addObject("productList", this.productDAO.list());
		model.setViewName("product");
		return model;
	}
}
