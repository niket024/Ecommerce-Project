package com.nik.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nik.model.ContactUs;
@Repository("contactUsDao")
public class ContactUsdaoImpl implements ContactUsDao {
	@Autowired
	private SessionFactory sessionFactory;

	public ContactUsdaoImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	@Override
	@Transactional
	public void saveEnquiery(ContactUs contactUs) {
		sessionFactory.getCurrentSession().saveOrUpdate(contactUs);
		
	}
}
