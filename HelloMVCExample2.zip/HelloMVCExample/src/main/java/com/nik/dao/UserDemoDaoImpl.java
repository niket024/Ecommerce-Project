package com.nik.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nik.model.UserDemo;
@Repository("userDemoDao")
public class UserDemoDaoImpl implements UserDemoDao {
	@Autowired
	private SessionFactory sessionFactory;

	public UserDemoDaoImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	@Override
	@Transactional
	public void saveUser(UserDemo userDemo) {
		Session session = sessionFactory.getCurrentSession();
		session.save(userDemo);
	}
}
