package com.nik.dao;

import com.nik.model.ContactUs;

public interface ContactUsDao {
	void saveEnquiery(ContactUs contactUs);
}
